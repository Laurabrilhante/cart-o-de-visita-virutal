import React from 'react';
import './Header.css';

function Header() {
    return (
        <>
            <header className="header">
                <img 
                    src="https://wallpaperaccess.com/full/1989420.jpg" 
                    alt="Banner do Header" 
                    className="header-image" 
                />
            </header>
        </>
    );
};

export default Header;
