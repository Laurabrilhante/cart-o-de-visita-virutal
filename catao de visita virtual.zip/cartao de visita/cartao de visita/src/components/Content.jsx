import React from 'react';
import './Content.css';

function Content(){
    return(
        <>
           <section>
                <h1>Noob Saibot</h1>   
                <h2>Noob Saibot é um jogador com muitas habilidades.Ele tem habilidades de sombra e controla a magia negra, um dos poderes mais marcante dele é fazer clones de sombra. </h2> 

                
                <img 
                    src="https://cdn.vox-cdn.com/thumbor/VZLSfFwb3PcIybvKUWsFiBHS8u0=/0x0:3840x2160/1920x0/filters:focal(0x0:3840x2160):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/22455489/noob_saibot_mk11.jpg" 
                    alt="imagem" 
                    className="imagem"
            
                />   
                <h3>Noob Saibot criando uma cópia dele para lutar contra os inimigos.</h3>

                <img 
                    src="https://4kwallpapers.com/images/wallpapers/noob-saibot-night-king-mortal-kombat-dark-5k-8k-2732x2732-1935.jpg" 
                    className="imagem"
                />   
                <h4>O personagem do jogo controlando magia negra.</h4>



                
           </section> 
        </>
    );
};
export default Content;